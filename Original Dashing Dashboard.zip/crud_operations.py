from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31545
        DB = 'AAC'
        COL = 'animals'

        # Initialize connection using f-strings or format method
        self.client = MongoClient(f"mongodb://{username}:{password}@{HOST}:{PORT}")
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, query):
        try:
            cursor = self.collection.find(query)
            result = list(cursor)
            return result
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []

    def update(self, query, new_values):
        try:
            self.collection.update_many(query, {"$set": new_values})
            return True
        except Exception as e:
            print(f"Error updating documents: {e}")
            return False


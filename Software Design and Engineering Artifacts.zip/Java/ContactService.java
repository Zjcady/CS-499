// ContactService class responsible for managing a list of contacts and providing CRUD operations
import java.util.ArrayList;
import java.util.List;

public class ContactService {
    // List to store contacts
    private List<Contact> contacts = new ArrayList<>();

    // Method to add a new contact to the list
    public void addContact(Contact contact) {
        // Basic validation to avoid adding duplicate contacts based on contactId
        if (getContactById(contact.getContactId()) == null) {
            contacts.add(contact);
        } else {
            System.out.println("Contact with this ID already exists.");
        }
    }

    // Method to get a contact by its unique ID
    public Contact getContactById(String contactId) {
        // Iterates through the list of contacts to find a match
        for (Contact contact : contacts) {
            if (contact.getContactId().equals(contactId)) {
                return contact;
            }
        }
        return null; // Returns null if no matching contact is found
    }

    // Method to delete a contact by its unique ID
    public boolean deleteContact(String contactId) {
        // Finds the contact and removes it if found
        Contact contact = getContactById(contactId);
        if (contact != null) {
            contacts.remove(contact);
            return true;
        }
        return false;
    }

    // Method to update an existing contact's details
    public boolean updateContact(String contactId, String newFirstName, String newLastName, String newPhone, String newAddress) {
        Contact contact = getContactById(contactId);
        if (contact != null) {
            // Updating fields with new data
            contact = new Contact(contactId, newFirstName, newLastName, newPhone, newAddress);
            return true;
        }
        return false;
    }

    // Additional helper methods can be added for sorting, searching, or other operations as required
}

// ContactServiceTest class for testing the ContactService class functionality
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;

    // Initializes the ContactService before each test
    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    // Test case for adding a contact
    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactById("12345"));
    }

    // Test case for deleting a contact
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.deleteContact("12345"));
        assertNull(contactService.getContactById("12345"));
    }

    // Test case for updating a contact
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.updateContact("12345", "Jane", "Smith", "0987654321", "456 Oak St"));
        Contact updatedContact = contactService.getContactById("12345");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Oak St", updatedContact.getAddress());
    }

    // Additional tests can be added to cover edge cases and validation scenarios
}

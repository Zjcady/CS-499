// Contact class representing a contact entity with basic information fields
public class Contact {
    // Private fields to encapsulate contact data
    private String contactId; // Unique identifier for the contact
    private String firstName; // First name of the contact
    private String lastName;  // Last name of the contact
    private String phone;     // Phone number of the contact
    private String address;   // Address of the contact

    // Constructor to initialize a Contact object with necessary details
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Getters for all fields - Allows external access to private fields without direct modification
    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Additional methods can be added here for any required functionality, 
    // such as validation of fields or formatting.
}

#include <fstream>
#include <sstream>
#include <iomanip>
#include "CSVparser.hpp"

namespace csv {

    Parser::Parser(const std::string &data, const DataType &type, char sep)
        : _type(type), _sep(sep) {
        std::string line;
        if (type == eFILE) {
            _file = data;
            std::ifstream ifile(_file.c_str());
            if (ifile.is_open()) {
                while (std::getline(ifile, line)) { // Better practice than using `while(ifile.good())`
                    if (!line.empty()) {
                        _originalFile.push_back(line);
                    }
                }
                ifile.close();

                if (_originalFile.empty())
                    throw Error(std::string("No Data in ").append(_file));

                parseHeader();
                parseContent();
            } else {
                throw Error(std::string("Failed to open ").append(_file));
            }
        } else {
            std::istringstream stream(data);
            while (std::getline(stream, line)) {
                if (!line.empty()) {
                    _originalFile.push_back(line);
                }
            }
            if (_originalFile.empty())
                throw Error(std::string("No Data in pure content"));

            parseHeader();
            parseContent();
        }
    }

    // Destructor
    Parser::~Parser() {
        for (const auto& row : _content) {
            // Smart pointers would handle deletion automatically if used
            delete row;
        }
    }

    void Parser::parseHeader() {
        std::stringstream ss(_originalFile[0]);
        std::string item;
        while (std::getline(ss, item, _sep)) {
            _header.push_back(item);
        }
    }

    void Parser::parseContent() {
        auto it = _originalFile.begin();
        ++it; // Skip header

        for (; it != _originalFile.end(); ++it) {
            bool quoted = false;
            size_t tokenStart = 0;
            size_t i = 0;

            Row* row = new Row(_header);

            for (; i != it->length(); ++i) {
                if (it->at(i) == '"') {
                    quoted = !quoted; // Toggle quoted state
                } else if (it->at(i) == ',' && !quoted) {
                    row->push(it->substr(tokenStart, i - tokenStart));
                    tokenStart = i + 1;
                }
            }

            // Push remaining element
            row->push(it->substr(tokenStart, it->length() - tokenStart));

            // Check if the row has the correct number of columns
            if (row->size() != _header.size())
                throw Error("corrupted data !");
            
            _content.push_back(row);
        }
    }

    Row& Parser::getRow(unsigned int rowPosition) const {
        if (rowPosition < _content.size()) {
            return *(_content[rowPosition]);
        }
        throw Error("can't return this row (doesn't exist)");
    }

    Row& Parser::operator[](unsigned int rowPosition) const {
        return getRow(rowPosition);
    }

    unsigned int Parser::rowCount() const {
        return _content.size();
    }

    unsigned int Parser::columnCount() const {
        return _header.size();
    }

    std::vector<std::string> Parser::getHeader() const {
        return _header;
    }

    const std::string Parser::getHeaderElement(unsigned int pos) const {
        if (pos >= _header.size())
            throw Error("can't return this header (doesn't exist)");
        return _header[pos];
    }

    bool Parser::deleteRow(unsigned int pos) {
        if (pos < _content.size()) {
            delete _content[pos]; // Deallocate memory
            _content.erase(_content.begin() + pos); // Remove the pointer from the vector
            return true;
        }
        return false;
    }

    bool Parser::addRow(unsigned int pos, const std::vector<std::string>& r) {
        auto row = new Row(_header);
        for (const auto& value : r) {
            row->push(value);
        }

        if (pos <= _content.size()) {
            _content.insert(_content.begin() + pos, row);
            return true;
        }
        delete row; // Prevent memory leak if position is invalid
        return false;
    }

    void Parser::sync() const {
        if (_type == DataType::eFILE) {
            std::ofstream f(_file, std::ios::out | std::ios::trunc);

            // Write header
            for (unsigned int i = 0; i < _header.size(); ++i) {
                f << _header[i];
                if (i < _header.size() - 1)
                    f << ",";
            }
            f << std::endl;

            // Write content
            for (const auto& row : _content) {
                f << *row << std::endl;
            }

            f.close();
        }
    }

    const std::string& Parser::getFileName() const {
        return _file;
    }

    /*
    ** Row Methods
    */

    Row::Row(const std::vector<std::string>& header)
        : _header(header) {}

    Row::~Row() = default;

    unsigned int Row::size() const {
        return _values.size();
    }

    void Row::push(const std::string& value) {
        _values.push_back(value);
    }

    bool Row::set(const std::string& key, const std::string& value) {
        auto it = std::find(_header.begin(), _header.end(), key);
        if (it != _header.end()) {
            auto index = std::distance(_header.begin(), it);
            _values[index] = value;
            return true;
        }
        return false;
    }

    const std::string Row::operator[](unsigned int valuePosition) const {
        if (valuePosition < _values.size()) {
            return _values[valuePosition];
        }
        throw Error("can't return this value (doesn't exist)");
    }

    const std::string Row::operator[](const std::string& key) const {
        auto it = std::find(_header.begin(), _header.end(), key);
        if (it != _header.end()) {
            auto index = std::distance(_header.begin(), it);
            return _values[index];
        }
        throw Error("can't return this value (doesn't exist)");
    }

    std::ostream& operator<<(std::ostream& os, const Row& row) {
        for (unsigned int i = 0; i < row._values.size(); ++i) {
            os << row._values[i];
            if (i < row._values.size() - 1) {
                os << " | ";
            }
        }
        return os;
    }

    std::ofstream& operator<<(std::ofstream& os, const Row& row) {
        for (unsigned int i = 0; i < row._values.size(); ++i) {
            os << row._values[i];
            if (i < row._values.size() - 1) {
                os << ",";
            }
        }
        return os;
    }
}

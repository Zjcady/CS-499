# Setup the Jupyter version of Dash
from jupyter_dash import JupyterDash

# Import necessary Dash modules
import dash_leaflet as dl
from dash import dcc, html, dash_table
from dash.dependencies import Input, Output

# Configure the necessary Python module imports
import pandas as pd
import numpy as np
import plotly.express as px

# MongoDB CRUD operations (make sure your CRUD module is named appropriately)
from crud_operations import AnimalShelter

# Set up MongoDB credentials
username = "aacuser"
password = "1234"
shelter = AnimalShelter(username, password)

# Read all documents from MongoDB
try:
    df = pd.DataFrame.from_records(shelter.read({}))  # Retrieve all documents
    if not df.empty:
        df.drop(columns=['_id'], inplace=True)  # Drop the '_id' column to avoid ObjectID issues
except Exception as e:
    print(f"Error retrieving data from MongoDB: {e}")
    df = pd.DataFrame()  # Return an empty DataFrame if an error occurs

# Initialize the Dash app
app = JupyterDash(__name__)

# Dashboard Layout / View
app.layout = html.Div([
    html.Center(html.B(html.H1('Zachary Cady\'s Dashing Dashboard'))),
    html.Hr(),
    
    dash_table.DataTable(
        id='datatable-id',
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict('records'),
        page_size=10,
        sort_action='native',
        filter_action='native',
        row_selectable='single',
        selected_rows=[0],
        style_table={'overflowX': 'auto'},  # Enable horizontal scrolling
    ),
    
    html.Br(),
    html.Hr(),
    
    html.Div(id='map-id', className='col s12 m6'),
])

#############################################
# Interaction Between Components / Controller
#############################################

# Callback to highlight selected columns in the DataTable
@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    [Input('datatable-id', 'selected_columns')]
)
def update_styles(selected_columns):
    if selected_columns:
        return [{
            'if': {'column_id': i},
            'background_color': '#D2F3FF'
        } for i in selected_columns]
    return []

# Callback to update the map based on selected data
@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('datatable-id', "derived_virtual_selected_rows")]
)
def update_map(viewData, index):
    if viewData is None or index is None:
        return []  # Return an empty map if no selection
    
    try:
        dff = pd.DataFrame.from_dict(viewData)
        row = index[0] if index else 0

        # Check if the required latitude and longitude columns are available
        lat_col, lon_col = 13, 14
        if len(dff.columns) > max(lat_col, lon_col):
            lat, lon = dff.iloc[row, lat_col], dff.iloc[row, lon_col]
            breed = dff.iloc[row, 4]
            name = dff.iloc[row, 9]
            
            return [
                dl.Map(style={'width': '1000px', 'height': '500px'},
                       center=[lat, lon], zoom=10, children=[
                           dl.TileLayer(id="base-layer-id"),
                           dl.Marker(position=[lat, lon], children=[
                               dl.Tooltip(breed),
                               dl.Popup([html.H1("Animal Name"), html.P(name)])
                           ])
                       ])
            ]
        else:
            print("Latitude and Longitude columns missing from data.")
    except Exception as e:
        print(f"Error updating map: {e}")
    
    return []

# Run the Dash app
app.run_server(debug=True)

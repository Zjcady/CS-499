//============================================================================
// Name        : VectorSorting.cpp
// Author      : Zachary Cady
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Vector Sorting Algorithms
//============================================================================

#include <algorithm>
#include <iostream>
#include <ctime> // Changed from time.h to ctime for C++ standard library
#include "CSVparser.hpp" // CSVparser for handling CSV files

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Forward declarations
double strToDouble(string str, char ch);

// Define a structure to hold bid information
struct Bid {
    string bidId;  // Unique identifier
    string title;
    string fund;
    double amount;

    // Default constructor to initialize bid amount to 0.0
    Bid() : amount(0.0) {}
};

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(const Bid& bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | " << bid.fund << endl;
}

/**
 * Prompt user for bid information using console (std::in)
 *
 * @return Bid struct containing the bid info
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();
    string strAmount;
    getline(cin, strAmount);
    bid.amount = strToDouble(strAmount, '$');

    return bid;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
vector<Bid> loadBids(const string& csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    vector<Bid> bids;  // Vector to store bids

    // Initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // Loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            bids.push_back(bid); // Add bid to vector
        }
    } catch (const csv::Error& e) {
        cerr << "Error reading CSV: " << e.what() << endl;
    }

    return bids;
}

/**
 * Partition the vector of bids into two parts, low and high
 *
 * @param bids Address of the vector<Bid> instance to be partitioned
 * @param begin Beginning index to partition
 * @param end Ending index to partition
 * @return the partition point (high index)
 */
int partition(vector<Bid>& bids, int begin, int end) {
    int low = begin;
    int high = end;

    int mid = begin + (end - begin) / 2;  // Calculate midpoint
    string pivot = bids[mid].title;       // Choose pivot point

    bool done = false;
    while (!done) {
        // Move low index forward if current bid title is less than pivot
        while (bids[low].title.compare(pivot) < 0) {
            ++low;
        }

        // Move high index backward if current bid title is greater than pivot
        while (bids[high].title.compare(pivot) > 0) {
            --high;
        }

        // If low and high indices have converged, partitioning is done
        if (low >= high) {
            done = true;
        } else {
            swap(bids[low], bids[high]);  // Swap bids at low and high

            // Move indices closer to the middle
            ++low;
            --high;
        }
    }

    return high;  // Return the partition point
}

/**
 * Perform a quick sort on bid titles
 * Average performance: O(n log(n))
 * Worst case performance: O(n^2)
 *
 * @param bids address of the vector<Bid> instance to be sorted
 * @param begin the beginning index to sort on
 * @param end the ending index to sort on
 */
void quickSort(vector<Bid>& bids, int begin, int end) {
    if (begin < end) {
        // Partition the bids into low and high parts
        int mid = partition(bids, begin, end);

        // Recursively sort low partition
        quickSort(bids, begin, mid);

        // Recursively sort high partition
        quickSort(bids, mid + 1, end);
    }
}

/**
 * Perform a selection sort on bid titles
 * Average and worst case performance: O(n^2)
 *
 * @param bids address of the vector<Bid> instance to be sorted
 */
void selectionSort(vector<Bid>& bids) {
    // Outer loop iterating over each position in the vector
    for (size_t pos = 0; pos < bids.size() - 1; ++pos) {
        size_t min = pos;  // Assume the current position is the smallest

        // Inner loop to find the smallest element in the remaining part
        for (size_t j = pos + 1; j < bids.size(); ++j) {
            if (bids[j].title.compare(bids[min].title) < 0) {
                min = j;  // Update minimum index if a smaller element is found
            }
        }

        // Swap the smallest element found with the current position
        if (min != pos) {
            swap(bids[pos], bids[min]);
        }
    }
}

/**
 * Convert a string to a double after removing unwanted characters
 *
 * @param str The string to convert
 * @param ch The character to strip out
 * @return the converted double
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());  // Remove character
    return atof(str.c_str());  // Convert string to double
}

/**
 * Main entry point of the program
 */
int main(int argc, char* argv[]) {
    string csvPath;

    // Handle command line arguments
    switch (argc) {
        case 2:
            csvPath = argv[1];
            break;
        default:
            csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
    }

    vector<Bid> bids;  // Vector to store bids
    clock_t ticks;  // Timer variable to measure performance

    int choice = 0;
    while (choice != 9) {
        // Display the menu
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Quick Sort All Bids" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                // Measure time to load bids
                ticks = clock();
                bids = loadBids(csvPath);
                cout << bids.size() << " bids read" << endl;
                ticks = clock() - ticks;
                cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 2:
                // Display all bids
                for (const auto& bid : bids) {
                    displayBid(bid);
                }
                cout << endl;
                break;

            case 3:
                // Perform Selection Sort
                ticks = clock();
                selectionSort(bids);
                ticks = clock() - ticks;
                cout << bids.size() << " bids sorted" << endl;
                cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 4:
                // Perform Quick Sort
                ticks = clock();
                quickSort(bids, 0, bids.size() - 1);
                ticks = clock() - ticks;
                cout << bids.size() << " bids sorted" << endl;
                cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 9:
                // Exit the program
                cout << "Goodbye." << endl;
                break;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}

#ifndef _CSVPARSER_HPP_
#define _CSVPARSER_HPP_

#include <stdexcept>
#include <string>
#include <vector>
#include <list>
#include <sstream>
#include <memory>  // For smart pointers

namespace csv {

    // Custom Error class inheriting from std::runtime_error
    class Error : public std::runtime_error {
    public:
        explicit Error(const std::string &msg) :
            std::runtime_error("CSVparser : " + msg) {}
    };

    // Row class to represent a row in the CSV file
    class Row {
    public:
        explicit Row(const std::vector<std::string> &header);
        ~Row() = default; // Destructor doesn't need to explicitly mention 'void'

    public:
        unsigned int size(void) const;
        void push(const std::string &value);
        bool set(const std::string &columnName, const std::string &value); // Set value in the row by column name

    private:
        const std::vector<std::string> _header;  // Column headers
        std::vector<std::string> _values;        // Row values

    public:
        // Template method to retrieve value of any type from a specific column position
        template<typename T>
        const T getValue(unsigned int pos) const {
            if (pos < _values.size()) {
                T res;
                std::stringstream ss(_values[pos]);
                ss >> res;
                return res;
            }
            throw Error("can't return this value (doesn't exist)");
        }

        const std::string operator[](unsigned int pos) const;
        const std::string operator[](const std::string &columnName) const;

        // Friend functions to allow easy output of Row contents
        friend std::ostream& operator<<(std::ostream& os, const Row &row);
        friend std::ofstream& operator<<(std::ofstream& os, const Row &row);
    };

    // Enum for the data source type (file or pure string content)
    enum DataType {
        eFILE = 0,
        ePURE = 1
    };

    // Parser class to handle CSV files
    class Parser {
    public:
        explicit Parser(const std::string &filePath, const DataType &type = eFILE, char sep = ',');
        ~Parser();  // Custom destructor is still required for cleaning up dynamically allocated memory

    public:
        Row &getRow(unsigned int row) const;
        unsigned int rowCount(void) const;
        unsigned int columnCount(void) const;
        std::vector<std::string> getHeader(void) const;
        const std::string getHeaderElement(unsigned int pos) const;
        const std::string &getFileName(void) const;

    public:
        bool deleteRow(unsigned int row);
        bool addRow(unsigned int pos, const std::vector<std::string> &newRow);
        void sync(void) const;  // Write any changes back to the file

    protected:
        void parseHeader(void);   // Parse the header from the CSV file
        void parseContent(void);  // Parse the content rows from the CSV file

    private:
        std::string _file;                          // Path to the file
        const DataType _type;                       // Type of data source (file or pure string)
        const char _sep;                            // Separator character (default is ',')
        std::vector<std::string> _originalFile;     // Original file content stored as strings
        std::vector<std::string> _header;           // Column headers
        std::vector<std::unique_ptr<Row>> _content; // Use unique_ptr for automatic memory management of Rows

    public:
        Row &operator[](unsigned int row) const;  // Access a row by index
    };
}

#endif // _CSVPARSER_HPP_

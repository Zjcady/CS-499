// ContactTest class for unit testing the Contact class
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    // Test case for creating a contact and checking its fields
    @Test
    public void testCreateContact() {
        // Create a new contact and verify all fields are set correctly
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // Additional tests can be added here for validating data (e.g., invalid inputs, special characters)
}
